
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { useAuth } from '@/contexts/AuthContext';
import { QrCode, ScanLine, History, LogOut, User } from 'lucide-react';

const Header: React.FC = () => {
  const { isAuthenticated, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2">
            <QrCode className="h-6 w-6 text-primary" />
            <span className="font-bold text-xl hidden sm:inline">ScanShare</span>
          </Link>
        </div>
        
        {isAuthenticated ? (
          <div className="flex items-center gap-4">
            <nav className="flex items-center gap-1 text-sm font-medium">
              <Link 
                to="/dashboard" 
                className={`px-3 py-2 rounded-md transition-colors ${
                  location.pathname === '/dashboard' 
                    ? 'bg-primary text-primary-foreground' 
                    : 'hover:bg-muted'
                }`}
              >
                <div className="flex items-center gap-2">
                  <QrCode className="h-4 w-4" />
                  <span className="hidden sm:inline">Generate</span>
                </div>
              </Link>
              
              <Link 
                to="/scan" 
                className={`px-3 py-2 rounded-md transition-colors ${
                  location.pathname === '/scan' 
                    ? 'bg-primary text-primary-foreground' 
                    : 'hover:bg-muted'
                }`}
              >
                <div className="flex items-center gap-2">
                  <ScanLine className="h-4 w-4" />
                  <span className="hidden sm:inline">Scan</span>
                </div>
              </Link>
              
              <Link 
                to="/history" 
                className={`px-3 py-2 rounded-md transition-colors ${
                  location.pathname === '/history' 
                    ? 'bg-primary text-primary-foreground' 
                    : 'hover:bg-muted'
                }`}
              >
                <div className="flex items-center gap-2">
                  <History className="h-4 w-4" />
                  <span className="hidden sm:inline">History</span>
                </div>
              </Link>
            </nav>
            
            <Button variant="ghost" size="icon" onClick={handleLogout} title="Logout">
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            {location.pathname !== '/login' && (
              <Button 
                variant="ghost" 
                onClick={() => navigate('/login')}
                className="flex items-center gap-2"
              >
                <User className="h-4 w-4" />
                <span>Login</span>
              </Button>
            )}
            
            {location.pathname !== '/register' && (
              <Button 
                variant="default" 
                onClick={() => navigate('/register')}
              >
                Sign Up
              </Button>
            )}
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
