import React from 'react';
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';
import { QrCode, ScanLine, History, CheckCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const Index = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  
  const features = [
    {
      icon: <QrCode className="h-6 w-6" />,
      title: 'Generate QR Codes',
      description: 'Create QR codes from any URL or text in seconds',
    },
    {
      icon: <ScanLine className="h-6 w-6" />,
      title: 'Scan with Ease',
      description: 'Use your device camera to scan any QR code instantly',
    },
    {
      icon: <History className="h-6 w-6" />,
      title: 'Track History',
      description: 'Keep a record of all your scanned and generated QR codes',
    },
    {
      icon: <CheckCircle className="h-6 w-6" />,
      title: 'Secure & Fast',
      description: 'Your data stays on your device. No server connection needed',
    },
  ];
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800">
      <header className="sticky top-0 z-50 backdrop-blur-lg bg-gray-800 border-b border-gray-700">
        <div className="container mx-auto px-4 py-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <QrCode className="h-7 w-7 text-yellow-400" />
              <span className="font-bold text-2xl bg-gradient-to-r from-yellow-400 to-red-600 bg-clip-text text-transparent">QR Code Generator</span>
            </div>
            
            <div className="flex items-center space-x-4">
              {isAuthenticated ? (
                <Button className="shadow-lg hover:shadow-yellow-400" onClick={() => navigate('/dashboard')}>Go to Dashboard</Button>
              ) : (
                <>
                  <Button variant="ghost" className="hover:bg-gray-700" onClick={() => navigate('/login')}>Login</Button>
                  <Button className="shadow-lg hover:shadow-yellow-400" onClick={() => navigate('/register')}>Sign Up</Button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>
      
      <main>
        {/* Hero Section */}
        <section className="py-20 lg:py-32 relative overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
              <div className="flex-1 text-center lg:text-left space-y-6">
                <h1 className="text-5xl lg:text-6xl font-bold leading-tight text-white">
                  <span className="bg-gradient-to-r from-yellow-400 to-red-600 bg-clip-text text-transparent">Scan, Share, Capture</span>
                  <br />
                  <span className="text-gray-300">QR Codes Made Simple</span>
                </h1>
                <p className="text-xl text-gray-400">
                  Generate, scan, and track QR codes all in one place.
                  No sign-up required to get started.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                  <Button size="lg" className="shadow-xl hover:shadow-yellow-400 transition-all" onClick={() => navigate('/dashboard')}>
                    <QrCode className="h-5 w-5 mr-2" />
                    Generate QR Code
                  </Button>
                  <Button size="lg" variant="outline" className="hover:bg-gray-700" onClick={() => navigate('/scan')}>
                    <ScanLine className="h-5 w-5 mr-2" />
                    Scan QR Code
                  </Button>
                </div>
              </div>
              
              <div className="flex-1">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/30 to-red-600/30 blur-3xl rounded-full"></div>
                  <div className="relative bg-gray-800 rounded-2xl shadow-2xl p-8">
                    <div className="grid grid-cols-2 gap-6">
                      <div className="aspect-square bg-yellow-400/10 rounded-lg flex items-center justify-center p-4">
                        <QrCode className="h-12 w-12 text-yellow-400" />
                      </div>
                      <div className="aspect-square bg-gray-700 rounded-lg flex items-center justify-center p-4">
                        <ScanLine className="h-12 w-12 text-gray-300" />
                      </div>
                      <div className="aspect-square bg-gray-700 rounded-lg flex items-center justify-center p-4">
                        <History className="h-12 w-12 text-gray-300" />
                      </div>
                      <div className="aspect-square bg-yellow-400/10 rounded-lg flex items-center justify-center p-4">
                        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-yellow-400">
                          <rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" />
                          <rect x="6" y="30" width="12" height="12" rx="2" fill="currentColor" />
                          <rect x="30" y="6" width="12" height="12" rx="2" fill="currentColor" />
                          <rect x="30" y="30" width="12" height="36" rx="2" fill="currentColor" opacity="0.2" />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Features Section */}
        <section className="py-20 bg-gray-900">
          <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold text-center mb-16 bg-gradient-to-r from-yellow-400 to-red-600 bg-clip-text text-transparent">Everything You Need</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <div key={index} className="bg-gray-800 rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
                  <div className="mb-6 w-14 h-14 rounded-xl bg-yellow-400/10 flex items-center justify-center text-yellow-400">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-3 text-white">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-yellow-400 to-red-600 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold mb-8">Ready to Get Started?</h2>
            <p className="text-xl mb-10 max-w-2xl mx-auto opacity-90">
              Generate your first QR code in seconds - no account required
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                className="shadow-xl hover:shadow-white/25 transition-all"
                onClick={() => navigate('/dashboard')}
              >
                <QrCode className="h-5 w-5 mr-2" />
                Generate QR Code
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="bg-transparent border-white hover:bg-white hover:text-primary transition-all"
                onClick={() => navigate('/register')}
              >
                Create Free Account
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <footer className="py-8 border-t border-gray-700">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center space-x-3">
              <QrCode className="h-6 w-6 text-yellow-400" />
              <span className="font-bold text-xl bg-gradient-to-r from-yellow-400 to-red-600 bg-clip-text text-transparent">QR Code Generator</span>
            </div>
            
            <div className="text-sm text-gray-400">
              © {new Date().getFullYear()} ScanShare. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
