import React from 'react';
import { LoginForm } from '@/components/AuthForms';
import { QrCode } from 'lucide-react';
import { Link } from 'react-router-dom';

const Login = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-900 text-white">
      <header className="w-full py-4 border-b border-gray-700">
        <div className="container">
          <Link to="/" className="flex items-center gap-2 w-fit">
            <QrCode className="h-6 w-6 text-yellow-400" />
            <span className="font-bold text-xl">QR Code</span>
          </Link>
        </div>
      </header>
      
      <main className="flex-1 container flex items-center justify-center py-12">
        <div className="w-full max-w-md bg-gray-800 p-6 rounded-lg shadow-lg">
          <LoginForm />
        </div>
      </main>
    </div>
  );
};

export default Login;
